# -*- coding: utf-8 -*-

"""Top-level package for pyriv."""

__author__ = """Haleigh Wright"""
__email__ = 'wright@umail.ucsb.edu'
__version__ = '0.1.0'
