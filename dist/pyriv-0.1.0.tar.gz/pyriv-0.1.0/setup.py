#!/usr/bin/env python
# -*- coding: utf-8 -*-

"""The setup script."""

import os
from setuptools import setup, find_packages

with open('README.rst') as readme_file:
    readme = readme_file.read()

with open('HISTORY.rst') as history_file:
    history = history_file.read()

#this is the list of dependencies that pip uses to install
requirements = [
    'Click>=6.0',
    'networkx>=1.10',
    'numpy',
]

setup_requirements = [
    # TODO(jkibele): put setup requirements (distutils extensions, etc.) here
]

test_requirements = [
    # TODO: put package test requirements here
]

setup(
    name='pyriv',
    version='0.1.0',
    description="pyriv calculates the distance from a given starting point to the closest coastal edge via waterways.",
    long_description=readme + '\n\n' + history,
    author="Jared Kibele",
    author_email='jkibele@ucsb.edu',
    url='https://github.com/jkibele/pyriv',
    download_url='https://github.com/jkibele/pyriv/archive/0.1.tar.gz',
    packages=find_packages(include=['pyriv'], exclude=['docs']),
    entry_points={
        'console_scripts': [
            'pyriv=pyriv.cli:main'
        ]
    },
    include_package_data=True,
    install_requires=requirements,
    license="MIT license",
    zip_safe=False,
    keywords='river distance pyriv',
    classifiers=[
        'Development Status :: 2 - Pre-Alpha',
        'Intended Audience :: Developers',
        'Topic :: Scientific/Engineering :: GIS',
        'License :: OSI Approved :: MIT License',
        'Natural Language :: English',
        "Programming Language :: Python :: 2",
        'Programming Language :: Python :: 2.6',
        'Programming Language :: Python :: 2.7',
    ],
    test_suite='tests',
    tests_require=test_requirements,
    setup_requires=setup_requirements,
)
