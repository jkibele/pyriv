=====
Usage
=====

To use pyriv in a project::

    import pyriv
